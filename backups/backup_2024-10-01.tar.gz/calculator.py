num1 = int(input("Enter first number: "))
num2 = int(input("Enter second number: "))
print(type(num1))
print(type(num2))
sum = num1 + num2
print(sum)
diff = num1 - num2
print(diff)
multiply = num1 * num2
print(multiply)
div = num1 / num2
print(div)