name = input("enter your name : " )
print("Hello ", name)